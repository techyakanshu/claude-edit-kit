@echo off
title Claude Editing Setup
set "CE_BAT=%~f0"
echo Claude Editing Setup shuru ho raha hai... (Windows popup aaye to Yes dabao)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=[IO.File]::ReadAllText($env:CE_BAT); $i=$s.IndexOf('#'+'#PS-START'); Invoke-Expression $s.Substring($i)"
echo.
pause
exit /b
##PS-START
$ClaudeMd = @'
# Claude Editing Kit - video editor instructions

You are a short-form video editor (Reels / Shorts / TikTok). The user is usually NOT technical: keep replies short, simple, in the user's own language (Hinglish if they write Hinglish). Do the technical work yourself; never ask them to run commands.

## Folders
- `1-Reference/` - reel(s) whose style to copy. The user may instead paste a link: download it with `yt-dlp -o "1-Reference/%(title).50s.%(ext)s" <link>`.
- `2-Meri-Video/` - the user's raw footage. NEVER modify or delete these files.
- `3-Final/` - finished exports only. Name them `<name>-v1.mp4`, `-v2`... never overwrite an older version.
- `.work/` - your scratch area (frames, transcripts, temp clips, Remotion project).

## Tools (installed by the kit)
ffmpeg, ffprobe, yt-dlp, node/npx, uv. On Mac they live in `~/.claude-edit/bin` - if a command is not found, run `export PATH="$HOME/.claude-edit/bin:$PATH"` first.
Install anything extra on demand, inside `.work/`:
- Captions / transcript: `uvx --from openai-whisper whisper <audio> --model turbo --word_timestamps True --output_dir .work`
- Background remove (cut-out): `uvx --from "rembg[cli]" rembg ...`
- Motion graphics / animated text: a Remotion project in `.work/motion` (`npx create-video@latest --yes --blank .work/motion`), render with `npx remotion render`.

## Workflow (follow in order)
1. **Look at the reference.** `ffprobe` it (length, fps, size). Extract a contact sheet (`ffmpeg -i ref.mp4 -vf "fps=2,scale=270:-1,tile=6x4" .work/ref-sheet.png`) and READ the image. Note: cut speed (avg shot length), caption style (font, size, position, colour, word-by-word or lines), zooms, b-roll, transitions, music/SFX, hook in first 2 s.
2. **Tell the user the plan in 4-6 bullets** (what you'll copy from the reference) and ask only what is truly missing (e.g. music?).
3. **Transcribe** the user's video with whisper (word timestamps).
4. **Rough cut:** remove silences, ums, retakes and dead air. Gaps between lines ~ 0.1-0.15 s. Strongest line first (hook).
5. **Style pass** to match the reference: captions (keyword highlighted), punch-in zooms on key words, b-roll/screen inserts, simple transitions, light SFX. Text never covers the face. Smooth eased motion, never linear.
6. **Export:** 1080x1920, 30 fps (or reference fps), H.264 high, yuv420p, AAC 48 kHz, `-movflags +faststart`, loudness around -14 LUFS. Keep the voice clean and on top of music.
7. **QA before showing:** ffprobe the file, make a frame sheet of the export and look at it (black frames, cut-off text, caption sync). Fix, then tell the user the path in `3-Final/`.
8. Feedback -> new version (`-v2`), never overwrite.

## Rules
- Never delete or overwrite the user's files. Never upload their video anywhere.
- Copyrighted music/b-roll: warn the user; prefer their own or royalty-free.
- If something fails, say so honestly and try another way.
'@
# Claude Editing Kit - Windows one-line setup (PowerShell)
# Kya karta hai: winget se ffmpeg, yt-dlp, Node.js, uv install karta hai
# aur Desktop par "Claude Editing" folder banata hai (CLAUDE.md = Claude ke editing instructions).
$ErrorActionPreference = 'Stop'

function Say($m) { Write-Host "> $m" -ForegroundColor Magenta }
function Ok($m)  { Write-Host "  OK $m" -ForegroundColor Green }

Write-Host "`nClaude Editing Kit - setup shuru`n" -ForegroundColor White

if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
  Write-Host "winget nahi mila. Microsoft Store se 'App Installer' update karo, phir dobara chalao." -ForegroundColor Red
  return
}

$pkgs = @(
  @{ id = 'Gyan.FFmpeg';         cmd = 'ffmpeg'; name = 'ffmpeg + ffprobe' },
  @{ id = 'yt-dlp.yt-dlp';       cmd = 'yt-dlp'; name = 'yt-dlp' },
  @{ id = 'OpenJS.NodeJS.LTS';   cmd = 'node';   name = 'Node.js' },
  @{ id = 'astral-sh.uv';        cmd = 'uv';     name = 'uv (Python helper)' }
)
foreach ($p in $pkgs) {
  if (Get-Command $p.cmd -ErrorAction SilentlyContinue) { Ok "$($p.name) pehle se hai"; continue }
  Say "$($p.name) install ho raha hai..."
  winget install --id $p.id -e --silent --accept-source-agreements --accept-package-agreements | Out-Null
  Ok $p.name
}

# PATH refresh (isi window mein naye tools dikh jayein)
$env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User')

# Editing folder (OneDrive Desktop bhi chalega)
$Desktop = [Environment]::GetFolderPath('Desktop')
$Work = if ($env:CE_WORK) { $env:CE_WORK } else { Join-Path $Desktop 'Claude Editing' }
Say "Desktop par 'Claude Editing' folder ban raha hai..."
foreach ($d in '1-Reference','2-Meri-Video','3-Final','.work') { New-Item -ItemType Directory -Force -Path (Join-Path $Work $d) | Out-Null }
$ClaudeMd | Set-Content -Encoding UTF8 (Join-Path $Work 'CLAUDE.md')
@"
1) 1-Reference  -> jis reel jaisa edit chahiye, wo reel yahan daalo (ya bas uska link Claude ko de do)
2) 2-Meri-Video -> apni raw video yahan daalo
3) Claude app kholo -> Code tab -> ye "Claude Editing" folder select karo
4) Likho: "meri video ko reference jaisa edit kar do"
5) Ready video 3-Final mein aa jayegi
"@ | Set-Content -Encoding UTF8 (Join-Path $Work 'START-HERE.txt')
Ok "Folder ready: $Work"

Write-Host "`nCheck:"
foreach ($t in 'ffmpeg','ffprobe','yt-dlp','node','npx','uv') {
  if (Get-Command $t -ErrorAction SilentlyContinue) { Ok $t } else { Write-Host "  X $t nahi mila (Claude app restart karke dekho)" -ForegroundColor Yellow }
}
Write-Host "`nSetup ho gaya! Claude app kholo -> Code tab -> Desktop\Claude Editing folder chuno." -ForegroundColor Green
Write-Host "Bolo: `"meri video ko reference jaisa edit kar do`"`n"
Start-Process explorer.exe $Work
