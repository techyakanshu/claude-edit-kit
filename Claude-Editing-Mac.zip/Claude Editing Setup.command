#!/bin/bash
# Claude Editing Kit — Mac one-line setup
#   Double-click karo. (Pehli baar: System Settings > Privacy & Security > Open Anyway)
# Kya karta hai: ffmpeg, ffprobe, yt-dlp, Node.js, uv download karta hai (Homebrew/password nahi chahiye)
# aur Desktop par "Claude Editing" folder banata hai jismein Claude ke liye editing instructions (CLAUDE.md) hain.
set -euo pipefail

TOOLS="${CE_TOOLS:-$HOME/.claude-edit}"
BIN="$TOOLS/bin"
WORK="${CE_WORK:-$HOME/Desktop/Claude Editing}"

say()  { printf "\033[1;35m▶\033[0m %s\n" "$1"; }
ok()   { printf "  \033[1;32m✓\033[0m %s\n" "$1"; }
have() { command -v "$1" >/dev/null 2>&1 || [ -x "$BIN/$1" ]; }

case "$(uname -m)" in
  arm64)  FF_ARCH=arm64; NODE_ARCH=arm64; UV_ARCH=aarch64 ;;
  x86_64) FF_ARCH=amd64; NODE_ARCH=x64;   UV_ARCH=x86_64 ;;
  *) echo "Ye Mac type support nahi hai: $(uname -m)"; exit 1 ;;
esac

printf "\n\033[1m🎬 Claude Editing Kit — setup shuru\033[0m\n\n"
mkdir -p "$BIN" "$TOOLS/tmp"
TMP="$(mktemp -d "$TOOLS/tmp/dl.XXXX")"
trap 'rm -rf "$TMP"' EXIT

# 1) ffmpeg + ffprobe (video cut, join, captions burn, export)
if have ffmpeg && have ffprobe; then ok "ffmpeg pehle se hai"; else
  say "ffmpeg download ho raha hai..."
  for t in ffmpeg ffprobe; do
    curl -fsSL "https://ffmpeg.martin-riedl.de/redirect/latest/macos/$FF_ARCH/release/$t.zip" -o "$TMP/$t.zip"
    unzip -oq "$TMP/$t.zip" -d "$TMP/$t"
    mv "$TMP/$t/$t" "$BIN/$t"; chmod +x "$BIN/$t"
  done
  ok "ffmpeg + ffprobe"
fi

# 2) yt-dlp (reference reels / b-roll download)
if have yt-dlp; then ok "yt-dlp pehle se hai"; else
  say "yt-dlp download ho raha hai..."
  curl -fsSL "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos" -o "$BIN/yt-dlp"
  chmod +x "$BIN/yt-dlp"; ok "yt-dlp"
fi

# 3) Node.js LTS (Remotion = motion graphics, text animation)
if have node; then ok "Node.js pehle se hai"; else
  say "Node.js download ho raha hai..."
  NODE_FILE="$(curl -fsSL https://nodejs.org/dist/latest-v24.x/SHASUMS256.txt | awk '{print $2}' | grep "darwin-$NODE_ARCH.tar.gz$" | head -1)"
  curl -fsSL "https://nodejs.org/dist/latest-v24.x/$NODE_FILE" -o "$TMP/node.tgz"
  rm -rf "$TOOLS/node"; mkdir -p "$TOOLS/node"
  tar -xzf "$TMP/node.tgz" -C "$TOOLS/node" --strip-components 1
  for t in node npm npx; do ln -sf "$TOOLS/node/bin/$t" "$BIN/$t"; done
  ok "Node.js (${NODE_FILE%.tar.gz})"
fi

# 4) uv (Python tools on-demand: whisper captions, background remove)
if have uv; then ok "uv pehle se hai"; else
  say "uv (Python helper) download ho raha hai..."
  curl -fsSL "https://github.com/astral-sh/uv/releases/latest/download/uv-$UV_ARCH-apple-darwin.tar.gz" -o "$TMP/uv.tgz"
  tar -xzf "$TMP/uv.tgz" -C "$TMP"
  mv "$TMP"/uv-*/uv "$TMP"/uv-*/uvx "$BIN/"; ok "uv"
fi

# 5) PATH — naye Terminal / Claude mein tools mil jayein
LINE="export PATH=\"$BIN:\$PATH\""
for rc in "$HOME/.zshrc" "$HOME/.bash_profile"; do
  touch "$rc"; grep -qF "$BIN" "$rc" || printf "\n# Claude Editing Kit\n%s\n" "$LINE" >> "$rc"
done
export PATH="$BIN:$PATH"

# 6) Editing folder + Claude ka brain
say "Desktop par 'Claude Editing' folder ban raha hai..."
mkdir -p "$WORK/1-Reference" "$WORK/2-Meri-Video" "$WORK/3-Final" "$WORK/.work"
cat > "$WORK/CLAUDE.md" <<'CLAUDEMD_EOF'
# Claude Editing Kit — video editor instructions

You are a short-form video editor (Reels / Shorts / TikTok). The user is usually NOT technical: keep replies short, simple, in the user's own language (Hinglish if they write Hinglish). Do the technical work yourself; never ask them to run commands.

## Folders
- `1-Reference/` — reel(s) whose style to copy. The user may instead paste a link: download it with `yt-dlp -o "1-Reference/%(title).50s.%(ext)s" <link>`.
- `2-Meri-Video/` — the user's raw footage. NEVER modify or delete these files.
- `3-Final/` — finished exports only. Name them `<name>-v1.mp4`, `-v2`… never overwrite an older version.
- `.work/` — your scratch area (frames, transcripts, temp clips, Remotion project).

## Tools (installed by the kit)
ffmpeg, ffprobe, yt-dlp, node/npx, uv. On Mac they live in `~/.claude-edit/bin` — if a command is not found, run `export PATH="$HOME/.claude-edit/bin:$PATH"` first.
Install anything extra on demand, inside `.work/`:
- Captions / transcript: `uvx --from openai-whisper whisper <audio> --model turbo --word_timestamps True --output_dir .work`
- Background remove (cut-out): `uvx --from "rembg[cli]" rembg ...`
- Motion graphics / animated text: a Remotion project in `.work/motion` (`npx create-video@latest --yes --blank .work/motion`), render with `npx remotion render`.

## Workflow (follow in order)
1. **Look at the reference.** `ffprobe` it (length, fps, size). Extract a contact sheet (`ffmpeg -i ref.mp4 -vf "fps=2,scale=270:-1,tile=6x4" .work/ref-sheet.png`) and READ the image. Note: cut speed (avg shot length), caption style (font, size, position, colour, word-by-word or lines), zooms, b-roll, transitions, music/SFX, hook in first 2 s.
2. **Tell the user the plan in 4–6 bullets** (what you'll copy from the reference) and ask only what is truly missing (e.g. music?).
3. **Transcribe** the user's video with whisper (word timestamps).
4. **Rough cut:** remove silences, ums, retakes and dead air. Gaps between lines ≈ 0.1–0.15 s. Strongest line first (hook).
5. **Style pass** to match the reference: captions (keyword highlighted), punch-in zooms on key words, b-roll/screen inserts, simple transitions, light SFX. Text never covers the face. Smooth eased motion, never linear.
6. **Export:** 1080×1920, 30 fps (or reference fps), H.264 high, yuv420p, AAC 48 kHz, `-movflags +faststart`, loudness around -14 LUFS. Keep the voice clean and on top of music.
7. **QA before showing:** ffprobe the file, make a frame sheet of the export and look at it (black frames, cut-off text, caption sync). Fix, then tell the user the path in `3-Final/`.
8. Feedback → new version (`-v2`), never overwrite.

## Rules
- Never delete or overwrite the user's files. Never upload their video anywhere.
- Copyrighted music/b-roll: warn the user; prefer their own or royalty-free.
- If something fails, say so honestly and try another way.
CLAUDEMD_EOF
cat > "$WORK/START-HERE.txt" <<'EOF'
1) 1-Reference  -> jis reel jaisa edit chahiye, wo reel yahan daalo (ya bas uska link Claude ko de do)
2) 2-Meri-Video -> apni raw video yahan daalo
3) Claude app kholo -> Code tab -> ye "Claude Editing" folder select karo
4) Likho: "meri video ko reference jaisa edit kar do"
5) Ready video 3-Final mein aa jayegi
EOF
ok "Folder ready: $WORK"

# 7) Check
printf "\n\033[1mCheck:\033[0m\n"
for t in ffmpeg ffprobe yt-dlp node npx uv; do
  if command -v "$t" >/dev/null 2>&1; then ok "$t"; else echo "  ✗ $t nahi mila"; fi
done
printf "\n\033[1;32m✅ Setup ho gaya!\033[0m Ab Claude app kholo → Code tab → Desktop/Claude Editing folder chuno.\n"
printf "   Bolo: \033[1m\"meri video ko reference jaisa edit kar do\"\033[0m\n\n"
open "$WORK" 2>/dev/null || true
printf "Ye window ab band kar sakte ho.\n"
